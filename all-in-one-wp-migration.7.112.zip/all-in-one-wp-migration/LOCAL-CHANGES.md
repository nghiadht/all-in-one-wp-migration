# Bản chỉnh sửa upload từng phần

Ngày sửa: 2026-10-22. Dựa trên All-in-One WP Migration 7.112.
Phiên bản nội bộ: 7.112.1 (Local Chunked Build). Đây là bản chỉnh sửa độc lập,
không phải bản phát hành chính thức của ServMask. Giữ giấy phép GPLv3 của dự án.

## Cài đặt

1. Tạo bản sao lưu website hoặc thử trên staging trước khi thay plugin.
2. Tắt All-in-One WP Migration Unlimited Extension nếu đang bật. Không dùng
   đồng thời các extension thay thế bộ upload/import với bản chỉnh sửa này.
3. Vào Plugins → Add New → Upload Plugin, chọn ZIP này. Nếu WordPress báo
   plugin đã tồn tại, chọn thay thế plugin hiện tại bằng bản tải lên.
4. Kích hoạt plugin, tải lại trang quản trị (Ctrl+F5), vào All-in-One WP Migration
   → Import → File và chọn file .wpress.
5. Giữ tab mở trong suốt quá trình upload và import. Khi tải xong, vẫn cần
   xác nhận bước import theo giao diện của plugin.

## Cách hoạt động

- Upload từng phần thô khoảng 1 MiB; giảm kích thước nếu máy chủ trả HTTP 413.
- Không áp giới hạn tổng file theo wp_max_upload_size(). JavaScript và PHP vẫn
  có giới hạn biểu diễn số và kích thước file; không phải dung lượng vô hạn.
- Gửi tuần tự, thử lại tối đa 5 lần với lỗi mạng hoặc lỗi máy chủ tạm thời.
- Khóa phiên upload, kiểm tra tổng byte và thứ tự; gửi lại cùng dữ liệu không
  làm ghi trùng. Dữ liệu chưa commit được loại bỏ khi thử lại.
- File .uploading chỉ đổi thành .wpress sau khi nhận đủ byte. Bộ kiểm tra
  archive, CRC (nếu có), nén, mã hóa và luồng import gốc vẫn chạy sau đó.
- Giữ xác thực secret_key của plugin; upload từng phần còn yêu cầu người dùng
  đang đăng nhập với quyền ai1wm_import_site.
- Không dùng mã kích hoạt, thư viện hoặc dịch vụ WebAssembly của Unlimited
  Extension. Không thay đổi hay giả lập xác thực license của nhà cung cấp.
- Thay đổi chỉ dành cho upload từ trang Import trên trình duyệt. Luồng upload
  nguyên file cũ được giữ để tương thích với các cách gọi hiện có, gồm REST.

## Điều kiện và giới hạn thực tế

- Cần PHP 64-bit cho upload từng phần và file lớn hơn 2 GiB.
- Cần đủ dung lượng cho file backup, dữ liệu giải nén và dữ liệu website.
  Không cần tăng memory_limit lên bằng dung lượng file backup.
- PHP, proxy, CDN và WAF vẫn phải cho phép từng request nhỏ. Bộ upload có
  thể giảm chunk xuống 16 KiB; nếu tầng mạng vẫn chặn thì phải chỉnh hosting.
- Tắt tab, tải lại trang hoặc đăng xuất sẽ không tiếp tục được phiên upload
  cũ. Hãy hủy và bắt đầu lại; chức năng thử lại chỉ áp dụng trong tab hiện tại.
- Việc bỏ giới hạn upload không bảo đảm một backup bất kỳ sẽ import thành công.
  Lỗi database, thiếu dung lượng, archive hỏng hoặc cấu hình server vẫn có thể xảy ra.
- Cập nhật plugin từ kho chính thức có thể ghi đè các thay đổi; cần đối chiếu
  và áp dụng lại bản sửa cho phiên bản mới.

## Tệp đã sửa hoặc thêm

- all-in-one-wp-migration.php: tên bản tùy chỉnh và phiên bản.
- constants.php: phiên bản dùng cho cache tài nguyên.
- loader.php: nạp receiver mới.
- lib/controller/class-ai1wm-main-controller.php: cấu hình và phụ thuộc script.
- lib/model/import/class-ai1wm-import-upload.php: định tuyến request từng phần.
- lib/model/import/class-ai1wm-import-chunked-upload.php: receiver mới.
- lib/view/assets/javascript/import.min.js: nối bộ upload cũ với transport mới.
- lib/view/assets/javascript/chunked-upload.js: transport mới, mã dễ đọc.
- lib/view/import/pro.php: thông báo đúng với cơ chế từng phần.
- LOCAL-CHANGES.md: tài liệu này.

## Kiểm thử

- Kiểm tra cú pháp toàn bộ 172 tệp PHP bằng PHP 8.3.6 và hai tệp JavaScript đã sửa/thêm.
- 32 kiểm tra HTTP/PHP qua controller import gốc, với các dịch vụ WordPress
  được giả lập: upload file .wpress hơn 12 MiB qua PHP giới hạn upload 2 MiB,
  so khớp SHA-256 của file ghép, validator/extractor gốc chấp nhận và đọc được
  package.json; kiểm tra thử lại, dữ liệu lệch, thứ tự, quyền và đường dẫn.
- Kiểm tra offset 10 GiB bằng file sparse có metadata được tạo sẵn: chỉ kiểm
  tra thao tác seek/ghi ở offset lớn, không phải tải toàn bộ 10 GiB.
- 11 kiểm tra JavaScript bằng transport giả lập: file ảo 10 GiB, HTTP 413,
  lỗi mạng, thử lại có giới hạn, hủy, phản hồi sai và thời điểm bắt đầu import.
- Chưa kiểm thử khôi phục database/website đầy đủ trên một cài đặt WordPress
  thật, cũng chưa import một backup thật 10 GiB. Cần kiểm tra trên staging.
