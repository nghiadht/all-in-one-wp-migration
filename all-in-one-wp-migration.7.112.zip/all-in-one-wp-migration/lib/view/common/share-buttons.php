<?php
/**
 * Copyright (C) 2014-2025 ServMask Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Attribution: This code is part of the All-in-One WP Migration plugin, developed by
 *
 * ███████╗███████╗██████╗ ██╗   ██╗███╗   ███╗ █████╗ ███████╗██╗  ██╗
 * ██╔════╝██╔════╝██╔══██╗██║   ██║████╗ ████║██╔══██╗██╔════╝██║ ██╔╝
 * ███████╗█████╗  ██████╔╝██║   ██║██╔████╔██║███████║███████╗█████╔╝
 * ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██║╚██╔╝██║██╔══██║╚════██║██╔═██╗
 * ███████║███████╗██║  ██║ ╚████╔╝ ██║ ╚═╝ ██║██║  ██║███████║██║  ██╗
 * ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Kangaroos cannot jump here' );
}
?>

<div class="ai1wm-social-share-wrapper">
	<a href="https://twitter.com/intent/tweet?text=Check+this+epic+WordPress+Migration+plugin&url=https://servmask.com&via=servmask"
		class="ai1wm-social-icon icon-x"
		target="_blank"
		rel="noopener"
		title="<?php esc_attr_e( 'Share on X', 'all-in-one-wp-migration' ); ?>"
		aria-label="<?php esc_attr_e( 'Share on X', 'all-in-one-wp-migration' ); ?>">
		<i class="ai1wm-icon-x" aria-hidden="true"></i>
	</a>

	<a href="https://www.facebook.com/sharer/sharer.php?u=https://servmask.com"
		class="ai1wm-social-icon icon-facebook"
		target="_blank"
		rel="noopener"
		title="<?php esc_attr_e( 'Share on Facebook', 'all-in-one-wp-migration' ); ?>"
		aria-label="<?php esc_attr_e( 'Share on Facebook', 'all-in-one-wp-migration' ); ?>">
		<i class="ai1wm-icon-facebook" aria-hidden="true"></i>
	</a>

	<a href="https://www.youtube.com/channel/UCWMNPEnX7KyDLknpcmPaSwg?sub_confirmation=1"
		class="ai1wm-social-icon icon-youtube"
		target="_blank"
		rel="noopener"
		title="<?php esc_attr_e( 'Subscribe on YouTube', 'all-in-one-wp-migration' ); ?>"
		aria-label="<?php esc_attr_e( 'Subscribe on YouTube', 'all-in-one-wp-migration' ); ?>">
		<i class="ai1wm-icon-youtube" aria-hidden="true"></i>
	</a>
</div>
