<?php
/**
 * Local modification, 2026-10-22. GPL-3.0-or-later.
 * Standalone raw chunk uploads; no external extension or service is required.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ai1wm_Import_Chunked_Upload {
	/** Leave room for multipart fields below PHP's POST limit. */
	public static function chunk_size() {
		$post = ai1wm_parse_size( ini_get( 'post_max_size' ), AI1WM_MAX_CHUNK_SIZE );
		$upload = ai1wm_parse_size( ini_get( 'upload_max_filesize' ), AI1WM_MAX_CHUNK_SIZE );
		$post = $post > 0 ? $post : AI1WM_MAX_CHUNK_SIZE;
		$upload = $upload > 0 ? $upload : AI1WM_MAX_CHUNK_SIZE;
		$limit = min( 1024 * 1024, $upload, $post - 65536 );
		return $limit >= 16384 ? (int) $limit : 0;
	}

	private static function fail( $message, $code = 400 ) {
		throw new Ai1wm_Upload_Exception( $message, $code );
	}

	private static function number( $params, $key ) {
		if ( ! isset( $params[ $key ] ) || ! is_scalar( $params[ $key ] ) ) {
			self::fail( 'Missing upload offset or total size.' );
		}
		$value = (string) $params[ $key ];
		if ( ! preg_match( '/^(0|[1-9][0-9]{0,15})$/D', $value ) || (float) $value > 9007199254740991 ) {
			self::fail( 'Invalid upload offset or total size.' );
		}
		return (int) $value;
	}

	private static function save_state( $path, $state ) {
		$json = json_encode( $state );
		if ( false === $json || file_put_contents( $path . '.tmp', $json ) !== strlen( $json ) || ! rename( $path . '.tmp', $path ) ) {
			self::fail( 'Could not save upload progress. Check disk space and permissions.', 500 );
		}
	}

	/** Called only through the core import controller, which verifies secret_key. */
	public static function execute( $params ) {
		if ( ! current_user_can( 'ai1wm_import_site' ) ) {
			self::fail( 'Please sign in with permission to import this website.', 403 );
		}
		if ( PHP_INT_SIZE < 8 ) {
			self::fail( 'Chunked imports require 64-bit PHP.', 400 );
		}
		if ( ! empty( $params['ai1wm_manual_restore'] ) || ! isset( $params['storage'], $params['archive'] ) ||
			! is_string( $params['storage'] ) || ! preg_match( '/^[a-zA-Z0-9]{12}$/D', $params['storage'] ) ||
			! is_string( $params['archive'] ) || basename( $params['archive'] ) !== $params['archive'] ) {
			self::fail( 'Invalid upload destination.' );
		}
		if ( ! ai1wm_is_filename_supported( $params['archive'] ) ) {
			self::fail( 'Invalid archive file type. Only .wpress files are allowed.' );
		}
		$offset = self::number( $params, 'upload_offset' );
		$total = self::number( $params, 'upload_total_size' );
		if ( $total < Ai1wm_Archiver::HEADER_SIZE || $offset >= $total ) {
			self::fail( 'Invalid backup size or upload offset.' );
		}
		if ( ! isset( $_FILES['upload_file']['error'], $_FILES['upload_file']['tmp_name'] ) ||
			! is_int( $_FILES['upload_file']['error'] ) || ! is_string( $_FILES['upload_file']['tmp_name'] ) ) {
			self::fail( 'Missing upload chunk. Check PHP upload and POST limits.', 413 );
		}
		$error = $_FILES['upload_file']['error'];
		if ( UPLOAD_ERR_OK !== $error ) {
			self::fail( 'PHP rejected the upload chunk (error ' . $error . ').', in_array( $error, array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ? 413 : 400 );
		}
		$tmp = $_FILES['upload_file']['tmp_name'];
		if ( ! is_uploaded_file( $tmp ) ) {
			self::fail( 'Invalid uploaded chunk.' );
		}
		$bytes = filesize( $tmp );
		if ( false === $bytes || $bytes < 1 || $bytes > self::chunk_size() || $bytes > $total - $offset ) {
			self::fail( 'Invalid upload chunk size.', 413 );
		}
		if ( 0 === $offset && ! ai1wm_is_filedata_supported( $tmp ) ) {
			self::fail( 'Invalid backup header. Please select a .wpress backup.', 415 );
		}

		// Resolve using the original core path and extension validators.
		try {
			$archive = ai1wm_archive_path( $params );
		} catch ( Exception $e ) {
			self::fail( $e->getMessage() );
		}
		$part = $archive . '.uploading';
		$metadata = $archive . '.upload.json';
		$lock = @fopen( $archive . '.upload.lock', 'c' );
		if ( false === $lock ) {
			self::fail( 'Could not open the upload lock. Check storage permissions.', 500 );
		}
		$input = false;
		$output = false;
		try {
			if ( ! flock( $lock, LOCK_EX ) ) {
				self::fail( 'Could not lock the upload.', 500 );
			}
			clearstatcache();
			if ( is_file( $metadata ) ) {
				$state = json_decode( file_get_contents( $metadata ), true );
				if ( ! is_array( $state ) || ! isset( $state['total'], $state['received'] ) ||
					! is_int( $state['total'] ) || ! is_int( $state['received'] ) || $state['total'] !== $total ||
					$state['received'] < 0 || $state['received'] > $total ) {
					self::fail( 'Upload progress does not match this file. Start a new import.', 409 );
				}
			} else {
				if ( 0 !== $offset || is_file( $archive ) || is_file( $part ) ) {
					self::fail( 'Upload session is missing. Start a new import.', 409 );
				}
				$state = array( 'total' => $total, 'received' => 0 );
				self::save_state( $metadata, $state );
			}
			$received = $state['received'];
			$complete = $received === $total && is_file( $archive );
			$target = $complete ? $archive : $part;
			$output = @fopen( $target, $complete ? 'rb' : 'c+b' );
			$input = @fopen( $tmp, 'rb' );
			if ( false === $output || false === $input ) {
				self::fail( 'Could not open upload data. Check disk space and permissions.', 500 );
			}
			$stats = fstat( $output );
			if ( false === $stats || $stats['size'] < $received ) {
				self::fail( 'Uploaded data is missing. Start a new import.', 409 );
			}
			// Discard bytes left by a request interrupted before its metadata commit.
			if ( ! $complete && $stats['size'] > $received && ! ftruncate( $output, $received ) ) {
				self::fail( 'Could not recover the interrupted upload.', 500 );
			}
			if ( $offset > $received || ( $offset < $received && $offset + $bytes > $received ) ) {
				self::fail( 'Chunk is out of order. Start a new import.', 409 );
			}
			if ( 0 !== fseek( $output, $offset, SEEK_SET ) ) {
				self::fail( 'Could not seek to the upload position.', 500 );
			}
			$remaining = $bytes;
			$retry = $offset < $received;
			try {
				while ( $remaining > 0 ) {
					$data = fread( $input, min( 65536, $remaining ) );
					if ( false === $data || '' === $data ) {
						self::fail( 'Could not read the complete upload chunk.', 500 );
					}
					if ( $retry ) {
						if ( fread( $output, strlen( $data ) ) !== $data ) {
							self::fail( 'A retried chunk differs from the stored data.', 409 );
						}
					} else {
						$written = 0;
						while ( $written < strlen( $data ) ) {
							$count = fwrite( $output, substr( $data, $written ) );
							if ( false === $count || 0 === $count ) {
								self::fail( 'Could not write upload data. Check free disk space.', 500 );
							}
							$written += $count;
						}
					}
					$remaining -= strlen( $data );
				}
				if ( ! $retry ) {
					if ( ! fflush( $output ) ) {
						self::fail( 'Could not flush upload data to disk.', 500 );
					}
					$state['received'] = $offset + $bytes;
					self::save_state( $metadata, $state );
				}
			} catch ( Exception $e ) {
				if ( ! $retry && ! $complete ) {
					ftruncate( $output, $received );
					fflush( $output );
				}
				throw $e;
			}
			fclose( $output );
			$output = false;
			if ( $state['received'] === $total && ! $complete ) {
				if ( ! rename( $part, $archive ) ) {
					self::fail( 'Could not finalize the uploaded backup.', 500 );
				}
				$complete = true;
			}
			$result = array( 'errors' => array(), 'offset' => $offset + $bytes, 'complete' => $complete );
		} finally {
			if ( is_resource( $input ) ) {
				fclose( $input );
			}
			if ( is_resource( $output ) ) {
				fclose( $output );
			}
			flock( $lock, LOCK_UN );
			fclose( $lock );
		}
		ai1wm_json_response( $result );
		exit;
	}
}
